import qrcode
import os, uuid
from datetime import datetime

UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def generate_qr_for_text(text: str):
    filename = f"qr_{uuid.uuid4().hex}.png"
    path = os.path.join(UPLOAD_FOLDER, filename)
    img = qrcode.make(text)
    img.save(path)
    return path
