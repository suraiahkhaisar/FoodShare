import random
import os
from datetime import datetime

def simulate_ai_check(image_path: str, food_type: str = None, packaging: str = None, storage: str = None):
    """Enhanced AI model simulation with more realistic scoring.
    Labels: 'safe' (score>0.8), 'borderline' (0.4-0.8), 'unsafe' (<0.4)
    """
    # Base score influenced by image presence
    base = random.random()
    if image_path and os.path.exists(image_path):
        base = min(0.95, base + 0.2)
    
    # Adjust score based on food type
    if food_type:
        if food_type in ['dry', 'snacks']:
            base += 0.1  # Dry foods are generally safer
        elif food_type in ['veg', 'non-veg']:
            base += 0.05  # Fresh foods need more careful handling
    
    # Adjust score based on packaging
    if packaging:
        if packaging == 'sealed':
            base += 0.15  # Sealed packaging is much safer
        elif packaging == 'unsealed':
            base -= 0.1   # Unsealed is riskier
    
    # Adjust score based on storage
    if storage:
        if storage == 'cold':
            base += 0.1   # Cold storage is better
        elif storage == 'room':
            base -= 0.05  # Room temperature is riskier
    
    # Add some randomness for realistic variation
    base += random.uniform(-0.1, 0.1)
    base = max(0.0, min(1.0, base))  # Clamp between 0 and 1
    
    # Determine label based on score
    if base > 0.8:
        return round(base, 2), 'safe'
    elif base > 0.4:
        return round(base, 2), 'borderline'
    else:
        return round(base, 2), 'unsafe'

def get_ai_thresholds():
    """Get configurable AI thresholds for different risk levels"""
    return {
        'safe_threshold': 0.8,
        'borderline_threshold': 0.4,
        'high_risk_threshold': 0.2
    }
