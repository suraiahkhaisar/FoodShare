import os
from datetime import datetime
from flask_mail import Message
from flask import current_app

def _get_services():
    # Access shared instances set by app
    app = current_app
    mongo = app.extensions.get('mongo')
    mail = app.extensions.get('mail')
    return app, mongo, mail

def send_notification(user_id, notification_type, title, message, priority='normal'):
    """Send a notification to a user"""
    notification = {
        'user_id': user_id,
        'type': notification_type,
        'title': title,
        'message': message,
        'priority': priority,
        'read': False,
        'created_at': datetime.utcnow()
    }
    
    # Store in database
    _, mongo, _ = _get_services()
    mongo.db.notifications.insert_one(notification)
    
    # Send email if user has email notifications enabled
    user = mongo.db.users.find_one({'_id': user_id})
    if user and user.get('email_notifications', True):
        send_email_notification(user['email'], title, message)

def send_email_notification(email, subject, body):
    """Send email notification"""
    try:
        _, _, mail = _get_services()
        if not mail:
            return
        msg = Message(
            subject=f"FoodShare: {subject}",
            recipients=[email],
            body=body
        )
        mail.send(msg)
    except Exception as e:
        print(f"Failed to send email notification: {e}")

def get_user_notifications(user_id, limit=20):
    """Get notifications for a user"""
    _, mongo, _ = _get_services()
    return list(mongo.db.notifications.find({'user_id': user_id})
                .sort('created_at', -1)
                .limit(limit))

def mark_notification_read(notification_id, user_id):
    """Mark a notification as read"""
    _, mongo, _ = _get_services()
    mongo.db.notifications.update_one(
        {'_id': notification_id, 'user_id': user_id},
        {'$set': {'read': True}}
    )

def send_donation_approved_notification(donation_id):
    """Send notification when donation is approved"""
    _, mongo, _ = _get_services()
    donation = mongo.db.donations.find_one({'_id': donation_id})
    if donation:
        donor = mongo.db.users.find_one({'_id': donation['donor_id']})
        if donor:
            send_notification(
                donation['donor_id'],
                'donation_approved',
                'Donation Approved',
                f'Your donation "{donation["food_name"]}" has been approved and is now visible to recipients.',
                'success'
            )

def send_donation_claimed_notification(donation_id, recipient_id):
    """Send notification when donation is claimed"""
    _, mongo, _ = _get_services()
    donation = mongo.db.donations.find_one({'_id': donation_id})
    recipient = mongo.db.users.find_one({'_id': recipient_id})
    
    if donation and recipient:
        # Notify donor
        send_notification(
            donation['donor_id'],
            'donation_claimed',
            'Donation Claimed',
            f'Your donation "{donation["food_name"]}" has been claimed by {recipient["name"]}.',
            'info'
        )
        
        # Notify recipient
        send_notification(
            recipient_id,
            'claim_successful',
            'Claim Successful',
            f'You have successfully claimed "{donation["food_name"]}". Show your QR code at pickup.',
            'success'
        )

def send_expiry_warning_notification(donation_id, hours_left):
    """Send expiry warning notification"""
    _, mongo, _ = _get_services()
    donation = mongo.db.donations.find_one({'_id': donation_id})
    if donation:
        donor = mongo.db.users.find_one({'_id': donation['donor_id']})
        if donor:
            priority = 'high' if hours_left < 2 else 'normal'
            send_notification(
                donation['donor_id'],
                'expiry_warning',
                'Food Expiring Soon',
                f'Your donation "{donation["food_name"]}" will expire in {hours_left:.1f} hours. Consider sending to compost.',
                priority
            )

def send_feedback_notification(donation_id, rating, comments):
    """Send notification when feedback is received"""
    _, mongo, _ = _get_services()
    donation = mongo.db.donations.find_one({'_id': donation_id})
    if donation:
        donor = mongo.db.users.find_one({'_id': donation['donor_id']})
        if donor:
            send_notification(
                donation['donor_id'],
                'feedback_received',
                'Feedback Received',
                f'You received a {rating}-star rating for "{donation["food_name"]}". {comments if comments else ""}',
                'info'
            )

def send_fraud_alert_notification(admin_id, alert_type, description):
    """Send fraud alert to admin"""
    send_notification(
        admin_id,
        'fraud_alert',
        'Fraud Alert',
        f'{alert_type}: {description}',
        'high'
    )

def send_spoilage_alert_notification(admin_id, donation_count):
    """Send spoilage alert to admin"""
    send_notification(
        admin_id,
        'spoilage_alert',
        'Spoilage Alert',
        f'{donation_count} food items are at high risk of spoilage and need immediate attention.',
        'high'
    )
