import os, uuid
from PIL import Image

UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_EXT = {'.jpg', '.jpeg', '.png', '.webp'}
MAX_SIDE = 1600  # px
JPEG_QUALITY = 80

def _safe_ext(filename: str) -> str:
    name, ext = os.path.splitext(filename or '')
    ext = ext.lower()
    return ext if ext in ALLOWED_EXT else '.jpg'

def save_image(file_storage) -> str:
    """
    Validate and compress image. Converts to RGB JPEG (quality 80), max side 1600px.
    Returns relative path under static/uploads.
    """
    # Generate a safe filename
    ext = _safe_ext(getattr(file_storage, 'filename', ''))
    filename = f"img_{uuid.uuid4().hex}{ext}"
    path = os.path.join(UPLOAD_FOLDER, filename)

    # Load via Pillow, resize and convert
    img = Image.open(file_storage.stream)
    # Some PNGs have alpha; convert to RGB background white
    if img.mode in ("RGBA", "P"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3] if img.mode == 'RGBA' else None)
        img = bg
    else:
        img = img.convert('RGB')

    w, h = img.size
    scale = min(1.0, float(MAX_SIDE) / max(w, h))
    if scale < 1.0:
        new_size = (int(w * scale), int(h * scale))
        img = img.resize(new_size, Image.LANCZOS)

    # Save as JPEG for consistency and size
    # If original was webp, still save as JPEG for simplicity
    img.save(path, format='JPEG', quality=JPEG_QUALITY, optimize=True)
    # Normalize path to forward slashes for URL compatibility on Windows
    return path.replace('\\', '/')