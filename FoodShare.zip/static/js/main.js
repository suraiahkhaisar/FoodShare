// Global JS for FoodShare UI enhancements
console.log("FoodShare UI loaded");

// Toast helper
function showToast(message, opts={}){
  const container = document.getElementById('toastContainer');
  if (!container) return alert(message);
  const id = 't' + Date.now();
  const type = opts.type || 'info'; // 'success' | 'danger' | 'warning' | 'info'
  const delay = opts.delay || 3500;
  const headerIcon = {
    success: 'bi-check-circle-fill text-success',
    danger: 'bi-exclamation-triangle-fill text-danger',
    warning: 'bi-exclamation-circle-fill text-warning',
    info: 'bi-info-circle-fill text-primary'
  }[type];
  const el = document.createElement('div');
  el.className = 'toast align-items-center show shadow-soft';
  el.setAttribute('role','alert');
  el.setAttribute('aria-live','assertive');
  el.setAttribute('aria-atomic','true');
  el.id = id;
  el.innerHTML = `
    <div class="d-flex">
      <div class="toast-body d-flex align-items-center gap-2">
        <i class="bi ${headerIcon}"></i>
        <span>${message}</span>
      </div>
      <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>`;
  container.appendChild(el);
  const t = new bootstrap.Toast(el, { delay });
  t.show();
  setTimeout(() => { el.remove(); }, delay + 500);
}

// Loader overlay helper
function withLoader(promiseFactory, text='Loading...'){
  const existing = document.getElementById('globalLoader');
  if (!existing){
    const overlay = document.createElement('div');
    overlay.id = 'globalLoader';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(2,6,23,0.35);backdrop-filter:saturate(140%) blur(2px);display:flex;align-items:center;justify-content:center;z-index:1085;';
    overlay.innerHTML = '<div class="card p-3 shadow"><div class="d-flex align-items-center gap-2"><div class="spinner-border text-primary" role="status" style="width:1.6rem;height:1.6rem;"></div><span>'+text+'</span></div></div>';
    document.body.appendChild(overlay);
  }
  const done = () => { const ov = document.getElementById('globalLoader'); if (ov) ov.remove(); };
  try {
    const p = promiseFactory();
    return Promise.resolve(p).then(r => { done(); return r; }).catch(e => { done(); throw e; });
  } catch(e) {
    done(); throw e;
  }
}

// Helper: auto-dismiss Bootstrap alerts
window.addEventListener('load', () => {
  document.querySelectorAll('.alert').forEach(a => {
    setTimeout(() => {
      const alert = new bootstrap.Alert(a);
      alert.close();
    }, 5000);
  });
});
