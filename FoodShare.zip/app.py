import os, json, time, urllib.parse, urllib.request
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory, jsonify
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson.objectid import ObjectId
import uuid
from utils.qr import generate_qr_for_text
from utils.ai_check import simulate_ai_check
from utils.tokens import sign_payload, verify_token
from utils.notifications import (
    send_donation_approved_notification, 
    send_donation_claimed_notification,
    send_expiry_warning_notification,
    send_feedback_notification,
    get_user_notifications,
    mark_notification_read
)
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()
from apscheduler.schedulers.background import BackgroundScheduler
from flask_mail import Mail, Message


app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'devsecret')
app.config["MONGO_URI"] = os.getenv('MONGO_URI', 'mongodb://localhost:27017/fooddb')
# Limit upload size (default 8 MB; override with MAX_CONTENT_LENGTH_MB env var)
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH_MB', '8')) * 1024 * 1024
mongo = PyMongo(app)

# Create helpful indexes (safe to run on startup)
def ensure_indexes():
    try:
        mongo.db.users.create_index('email', unique=True)
        mongo.db.users.create_index('phone', unique=True)
        mongo.db.users.create_index([('role', 1), ('status', 1)])
        mongo.db.donations.create_index('status')
        mongo.db.donations.create_index('donor_id')
        mongo.db.donations.create_index('expires_at')
        mongo.db.claims.create_index('status')
        mongo.db.claims.create_index('recipient_id')
        mongo.db.claims.create_index('donation_id')
    except Exception as e:
        # Avoid crashing app if index creation fails
        print(f"Index creation warning: {e}")

ensure_indexes()

# Mail (optional)
mail = Mail(app)
# Expose resources for helpers to avoid circular imports
try:
    app.extensions  # ensure exists
except Exception:
    pass
app.extensions['mongo'] = mongo
app.extensions['mail'] = mail

# Auth helpers
from functools import wraps

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get('user'):
            return redirect(url_for('login', next=request.full_path))
        return f(*args, **kwargs)
    return wrapped

# Simple in-process throttle for geocoding
_last_geocode = {'t': 0}

@app.route('/api/geocode')
@login_required
def api_geocode():
    """Lightweight geocoding via Nominatim (OpenStreetMap).
    Query with ?q=...
    - Throttled to 1 request/second per server process.
    - Returns { ok: bool, lat, lng, display_name } or error.
    """
    user = current_user()
    q = (request.args.get('q') or '').strip()
    if not q:
        return jsonify({'ok': False, 'error': 'missing query'}), 400

    # throttle (1 req/sec)
    now_ts = time.time()
    if now_ts - _last_geocode['t'] < 1.0:
        time.sleep(1.0 - (now_ts - _last_geocode['t']))
    _last_geocode['t'] = time.time()

    try:
        url = 'https://nominatim.openstreetmap.org/search?' + urllib.parse.urlencode({
            'q': q,
            'format': 'json',
            'limit': 1
        })
        req = urllib.request.Request(url, headers={
            'User-Agent': 'FoodShareApp/1.0 (contact: example@example.com)'
        })
        with urllib.request.urlopen(req, timeout=7) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        if not data:
            return jsonify({'ok': False, 'error': 'no_results'}), 404
        item = data[0]
        return jsonify({
            'ok': True,
            'lat': float(item.get('lat')),
            'lng': float(item.get('lon')),
            'display_name': item.get('display_name')
        })
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500

UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ----- Helpers -----
def current_user():
    return session.get('user')

def log_action(actor_id, actor_role, action, target_type=None, target_id=None, details=None):
    try:
        mongo.db.audit_logs.insert_one({
            'actor_id': actor_id,
            'actor_role': actor_role,
            'action': action,
            'target_type': target_type,
            'target_id': target_id,
            'details': details or {},
            'timestamp': datetime.utcnow()
        })
    except Exception:
        # Avoid breaking main flow if logging fails
        pass

def login_required(f):
    from functools import wraps
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not current_user():
            # Preserve destination so user returns after login
            return redirect(url_for('login', next=request.full_path))
        return f(*args, **kwargs)
    return wrapped

# ----- Routes: Public -----
@app.route('/')
def index():
    user = current_user()
    return render_template('index.html', user=user)

# ----- Super Admin: Manage Users -----
@app.route('/super/users')
@login_required
def superadmin_users():
    user = current_user()
    if not user or user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    admins = list(mongo.db.users.find({'role': 'admin'}))
    return render_template('superadmin/users.html', user=user, admins=admins)

@app.route('/super/users/create_admin', methods=['GET','POST'])
@login_required
def superadmin_create_admin():
    user = current_user()
    if not user or user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        email = request.form.get('email','').strip().lower()
        phone = request.form.get('phone','').strip()
        password = request.form.get('password','')
        if not name or not email or not phone or not password:
            flash('All fields are required', 'danger')
            return redirect(url_for('superadmin_create_admin'))
        if mongo.db.users.find_one({'email': email}):
            flash('Email already exists', 'danger')
            return redirect(url_for('superadmin_create_admin'))
        if mongo.db.users.find_one({'phone': phone}):
            flash('Phone already exists', 'danger')
            return redirect(url_for('superadmin_create_admin'))
        admin_user = {
            '_id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'phone': phone,
            'password': generate_password_hash(password),
            'role': 'admin',
            'status': 'approved',
            'created_at': datetime.utcnow()
        }
        mongo.db.users.insert_one(admin_user)
        flash('Admin created successfully', 'success')
        return redirect(url_for('superadmin_users'))
    return render_template('superadmin/create_admin.html', user=user)

# ----- Auth -----
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        role = request.form.get('role', 'donor')

        # Basic validations
        if not name or not email or not phone or not password:
            flash('All fields are required', 'danger')
            return redirect(url_for('register'))
        # Password strength: min 8, upper, lower, digit
        import re
        if not re.search(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$', password or ''):
            flash('Password must be at least 8 chars and include upper, lower, and a digit.', 'danger')
            return redirect(url_for('register'))

        if mongo.db.users.find_one({'email': email}):
            flash('Email already exists', 'danger')
            return redirect(url_for('register'))
        if mongo.db.users.find_one({'phone': phone}):
            flash('Phone already exists', 'danger')
            return redirect(url_for('register'))

        # Restrict self-registration for admin and superadmin
        if role in ('admin','superadmin'):
            flash('Admin and Super Admin accounts cannot be self-registered. Please contact a Super Admin.', 'danger')
            return redirect(url_for('register'))

        # Role-based approval rules
        status = 'approved' if role == 'donor' else ('pending' if role in ('recipient',) else 'approved')

        user = {
            '_id': str(uuid.uuid4()),
            'name': name,
            'email': email,
            'phone': phone,
            'password': generate_password_hash(password),
            'role': role,
            'status': status,  # recipient -> pending verification
            'created_at': datetime.utcnow()
        }

        mongo.db.users.insert_one(user)
        if status == 'pending':
            flash('Registered. Your account requires approval before access.', 'warning')
        else:
            flash('Registered successfully. You can now login.', 'success')
        return redirect(url_for('login'))

    return render_template('auth/register.html')

# Utility: seed a fake inspector for testing
@app.route('/seed/fake_inspector')
def seed_fake_inspector():
    # Idempotent creator for a demo inspector account
    email = 'inspector@example.com'
    user = mongo.db.users.find_one({'email': email})
    if not user:
        doc = {
            '_id': str(uuid.uuid4()),
            'name': 'Food Inspector (Demo)',
            'email': email,
            'phone': '+10000000000',
            'password': generate_password_hash('Inspector@123'),
            'role': 'inspector',
            'status': 'approved',
            'created_at': datetime.utcnow()
        }
        mongo.db.users.insert_one(doc)
    return jsonify({'success': True, 'email': email, 'password': 'Inspector@123'})


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        next_url = request.args.get('next')
        user = mongo.db.users.find_one({'email': email})
        if not user or not check_password_hash(user['password'], password):
            flash('Invalid credentials', 'danger')
            return redirect(url_for('login', next=next_url))
        if user.get('status') != 'approved':
            flash('Account not approved yet.', 'warning')
            return redirect(url_for('login', next=next_url))
        session['user'] = {
            'id': user['_id'],
            'name': user['name'],
            'email': user['email'],
            'role': user['role']
        }
        # If user was trying to access a protected URL, send them back there
        if next_url:
            return redirect(next_url)
        # otherwise, redirect by role
        if user['role'] == 'donor':
            return redirect(url_for('donor_dashboard'))
        elif user['role'] == 'recipient':
            return redirect(url_for('recipient_map'))
        elif user['role'] == 'admin':
            return redirect(url_for('admin_pending'))
        elif user['role'] == 'inspector':
            return redirect(url_for('inspector_dashboard'))
        elif user['role'] == 'superadmin':
            return redirect(url_for('superadmin_dashboard'))
        return redirect(url_for('index'))
    return render_template('auth/login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Logged out', 'success')
    return redirect(url_for('index'))

# ----- Donor -----
@app.route('/donor/dashboard')
@login_required
def donor_dashboard():
    user = current_user()
    if user['role'] != 'donor':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    donations = list(mongo.db.donations.find({'donor_id': user['id']}))
    # Enrich with recipient info if claimed/collected
    for d in donations:
        if d.get('status') in ('claimed','collected'):
            claim = mongo.db.claims.find_one({'donation_id': d['_id']}, sort=[('claimed_at', -1)])
            if claim:
                recipient = mongo.db.users.find_one({'_id': claim.get('recipient_id')})
                if recipient:
                    d['recipient'] = {
                        'name': recipient.get('name'),
                        'email': recipient.get('email'),
                        'phone': recipient.get('phone')
                    }
                    # compatibility for template
                    d['assigned_recipient_user'] = d['recipient']
                    d['claim'] = {
                        'id': claim.get('_id'),
                        'status': claim.get('status'),
                        'claimed_at': claim.get('claimed_at'),
                        'collected_at': claim.get('collected_at')
                    }
    return render_template('donor/dashboard.html', donations=donations, user=user, now=datetime.utcnow())

@app.route('/donor/status/<donation_id>', methods=['POST'])
@login_required
def donor_update_status(donation_id):
    user = current_user()
    if user['role'] != 'donor':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    donation = mongo.db.donations.find_one({'_id': donation_id, 'donor_id': user['id']})
    if not donation:
        flash('Donation not found', 'danger')
        return redirect(url_for('donor_dashboard'))
    new_status = (request.form.get('status') or '').strip()
    if new_status not in ('approved','claimed','collected'):
        flash('Invalid status', 'danger')
        return redirect(request.referrer or url_for('donor_dashboard'))
    if new_status == 'claimed':
        claim = mongo.db.claims.find_one({'donation_id': donation_id}, sort=[('claimed_at', -1)])
        if not claim:
            flash('Cannot mark as claimed without a recipient claim.', 'warning')
            return redirect(request.referrer or url_for('donor_dashboard'))
        mongo.db.donations.update_one({'_id': donation_id}, {'$set': {'status': 'claimed'}})
    elif new_status == 'collected':
        mongo.db.donations.update_one({'_id': donation_id}, {'$set': {'status': 'collected'}})
        mongo.db.claims.update_one({'donation_id': donation_id}, {'$set': {'status': 'collected', 'collected_at': datetime.utcnow()}}, upsert=False)
    else:
        mongo.db.donations.update_one({'_id': donation_id}, {'$set': {'status': 'approved'}})
    flash('Status updated', 'success')
    return redirect(request.referrer or url_for('donor_dashboard'))

@app.route('/donor/map')
@login_required
def donor_map():
    user = current_user()
    if user['role'] != 'donor':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    # Show donor's own donations + nearby compost/NGO drop points (static demo dataset)
    # In production, fetch from DB or config
    drop_points = [
        { 'name': 'City Compost Center', 'lat': 12.972, 'lng': 77.593, 'type': 'compost' },
        { 'name': 'Helping Hands NGO', 'lat': 12.980, 'lng': 77.610, 'type': 'ngo' },
        { 'name': 'Green Earth Compost', 'lat': 13.005, 'lng': 77.580, 'type': 'compost' }
    ]
    donations = list(mongo.db.donations.find({'donor_id': user['id']}))
    return render_template('donor/map.html', donations=donations, drop_points=drop_points, user=user)

@app.route('/donor/add', methods=['GET','POST'])
@login_required
def donor_add():
    user = current_user()
    if user['role'] != 'donor':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    if request.method == 'POST':
        name = request.form.get('food_name')
        food_type = request.form.get('food_type')
        qty = int(request.form.get('quantity') or 1)
        prep_time = request.form.get('prep_time')
        expiry_hours = int(request.form.get('expiry_hours') or 4)
        packaging = request.form.get('packaging')
        storage = request.form.get('storage')
        lat = float(request.form.get('lat') or 0)
        lng = float(request.form.get('lng') or 0)
        donor_type = request.form.get('donor_type')
        donor_name = request.form.get('donor_name')
        donor_address = request.form.get('donor_address')
        donor_contact = request.form.get('donor_contact')
        pickup_instructions = request.form.get('pickup_instructions')
        files = request.files.getlist('photos') or []
        photos = []
        # Use safe validation/compression
        try:
            from utils.images import save_image
            for f in files:
                if f and getattr(f, 'filename', None):
                    photos.append(save_image(f))
            # Backward compatibility: if single 'photo' field used
            if not photos:
                file = request.files.get('photo')
                if file and file.filename:
                    photos.append(save_image(file))
        except Exception:
            # Fallback to raw save if Pillow fails
            for f in files:
                if f and getattr(f, 'filename', None):
                    filename = f"{uuid.uuid4().hex}_{f.filename}"
                    save_path = os.path.join(UPLOAD_FOLDER, filename)
                    f.save(save_path)
                    photos.append(save_path)
            if not photos:
                file = request.files.get('photo')
                if file and file.filename:
                    filename = f"{uuid.uuid4().hex}_{file.filename}"
                    save_path = os.path.join(UPLOAD_FOLDER, filename)
                    file.save(save_path)
                    photos.append(save_path)
        primary_photo = photos[0] if photos else ''
        # Optional multi-item support
        items = []
        try:
            items_json = request.form.get('items_json')
            if items_json:
                items = json.loads(items_json)
        except Exception:
            items = []
        if items:
            try:
                total_qty = sum(int(i.get('quantity') or 0) for i in items)
            except Exception:
                total_qty = 0
            types = [ (i.get('food_type') or '').lower() for i in items if i.get('food_type') ]
            agg_type = types[0] if len(set(t for t in types if t)) == 1 and types else 'mixed'
            # derive display name and aggregate fields (backward-compatible)
            base_name = (items[0].get('food_name') or name or 'Donation')
            name = f"{base_name} (+{len(items)-1} more)" if len(items) > 1 else base_name
            qty = total_qty or qty
            food_type = agg_type or (food_type or 'mixed')
        # simulate AI check (use primary photo and additional parameters)
        ai_score, ai_label = simulate_ai_check(primary_photo, food_type, packaging, storage)
        # Always start as pending_review so admin can see new uploads immediately
        donation = {
            '_id': str(uuid.uuid4()),
            'donor_id': user['id'],
            'food_name': name,
            'food_type': food_type,
            'quantity': qty,
            'prep_time': prep_time,
            'expiry_hours': expiry_hours,
            'packaging': packaging,
            'storage': storage,
            'location': {'lat': lat, 'lng': lng},
            'donor_type': donor_type,
            'donor_name': donor_name,
            'donor_address': donor_address,
            'donor_contact': donor_contact,
            'pickup_instructions': pickup_instructions,
            'photo': primary_photo,
            'photos': photos,
            'items': items,  # optional multi-item list: [{ food_name, food_type, quantity }]
            'ai_score': ai_score,
            'ai_label': ai_label,
            # Status: manual review for ALL new donations to improve admin visibility
            'status': 'pending_review',
            'assigned_recipient': None,
            'distribution_status': 'pending',
            'created_at': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(hours=expiry_hours)
        }
        mongo.db.donations.insert_one(donation)
        flash('Donation added', 'success')
        # After adding, redirect back if we came from a preserved next URL
        next_url = request.args.get('next')
        if next_url:
            return redirect(next_url)
        return redirect(url_for('donor_dashboard'))
    return render_template('donor/add_donation.html', user=user)

@app.route('/donor/download_qr/<donation_id>')
@login_required
def donor_download_qr(donation_id):
    donation = mongo.db.donations.find_one({'_id': donation_id})
    if not donation:
        flash('Donation not found', 'danger')
        return redirect(url_for('donor_dashboard'))
    qr_path = generate_qr_for_text(donation_id)
    return send_from_directory(os.path.dirname(qr_path), os.path.basename(qr_path), as_attachment=True)

# ----- Recipient -----
@app.route('/recipient/map')
@login_required
def recipient_map():
    user = current_user()
    if user['role'] != 'recipient':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    # fetch approved donations not expired
    now = datetime.utcnow()
    donations = list(mongo.db.donations.find({'status': 'approved', 'expires_at': {'$gt': now}}))

    # Fallback: assign dummy locations for donations missing lat/lng so recipients can see them on the map
    dummy_points = [
        {'lat': 20.5937, 'lng': 78.9629},  # India center
        {'lat': 20.6037, 'lng': 78.9729},
        {'lat': 20.5837, 'lng': 78.9529},
        {'lat': 20.5737, 'lng': 78.9429},
        {'lat': 20.6137, 'lng': 78.9829},
    ]
    idx = 0
    for d in donations:
        loc = (d.get('location') or {})
        lat = loc.get('lat')
        lng = loc.get('lng')
        # If lat/lng are missing, None, or 0/0, assign a dummy point
        if not isinstance(lat, (int, float)) or not isinstance(lng, (int, float)) or (float(lat) == 0.0 and float(lng) == 0.0):
            dp = dummy_points[idx % len(dummy_points)]
            d['location'] = {'lat': dp['lat'], 'lng': dp['lng']}
            idx += 1

    # Also show nearby NGO/compost drop points (static demo dataset)
    drop_points = [
        { 'name': 'City Compost Center', 'lat': 12.972, 'lng': 77.593, 'type': 'compost' },
        { 'name': 'Helping Hands NGO', 'lat': 12.980, 'lng': 77.610, 'type': 'ngo' },
        { 'name': 'Green Earth Compost', 'lat': 13.005, 'lng': 77.580, 'type': 'compost' }
    ]
    return render_template('recipient/map.html', donations=donations, drop_points=drop_points, user=user)

@app.route('/recipient/claim/<donation_id>', methods=['GET','POST'])
@login_required
def recipient_claim(donation_id):
    user = current_user()
    if user['role'] != 'recipient':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    donation = mongo.db.donations.find_one({'_id': donation_id, 'status': {'$in': ['approved']}})
    if not donation:
        flash('Donation not available', 'danger')
        return redirect(url_for('recipient_map'))
    if request.method == 'POST':
        claim_id = str(uuid.uuid4())
        # Signed token with short expiry for pickup verification (15 min)
        payload = {
            'type': 'claim',
            'claim_id': claim_id,
            'donation_id': donation_id,
            'recipient_id': user['id'],
            'exp': time.time() + 60*15
        }
        token = sign_payload(payload)
        # Encode a full URL in the QR so phone scanners open the page directly
        base = os.getenv('PUBLIC_BASE_URL') or request.url_root.rstrip('/')
        pickup_url = f"{base}/verify/pickup?t={token}"
        qr_path = generate_qr_for_text(pickup_url)
        claim = {
            '_id': claim_id,
            'donation_id': donation_id,
            'recipient_id': user['id'],
            'claimed_at': datetime.utcnow(),
            'status': 'claimed',
            'qr_token': token,
            'qr_path': qr_path
        }
        mongo.db.claims.insert_one(claim)
        # lock donation visibility
        mongo.db.donations.update_one({'_id': donation_id}, {'$set': {'status': 'claimed'}})
        
        # Send notifications
        send_donation_claimed_notification(donation_id, user['id'])
        
        flash('Claim created. Show QR at pickup.', 'success')
        return redirect(url_for('recipient_claim_qr', claim_id=claim_id))
    return render_template('recipient/claim.html', donation=donation, user=user)

# Show QR after claim
@app.route('/recipient/claim_qr/<claim_id>')
@login_required
def recipient_claim_qr(claim_id):
    user = current_user()
    claim = mongo.db.claims.find_one({'_id': claim_id, 'recipient_id': user['id']})
    if not claim:
        flash('Claim not found', 'danger')
        return redirect(url_for('recipient_map'))
    return render_template('recipient/claim_qr.html', claim=claim, user=user)

# Claim History
@app.route('/recipient/history')
@login_required
def recipient_claim_history():
    user = current_user()
    if user['role'] != 'recipient':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    claims = list(mongo.db.claims.find({'recipient_id': user['id']}).sort('claimed_at', -1))
    
    # Enrich claims with donation and donor info
    for claim in claims:
        donation = mongo.db.donations.find_one({'_id': claim['donation_id']})
        if donation:
            donor = mongo.db.users.find_one({'_id': donation['donor_id']})
            claim['donation'] = donation
            if donor:
                claim['donation']['donor'] = donor
    
    return render_template('recipient/history.html', claims=claims, user=user)

# Feedback System
@app.route('/recipient/feedback', methods=['GET','POST'])
@app.route('/recipient/feedback/<claim_id>', methods=['GET','POST'])
@login_required
def recipient_feedback(claim_id=None):
    user = current_user()
    if user['role'] != 'recipient':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    if claim_id:
        # Specific claim feedback
        claim = mongo.db.claims.find_one({'_id': claim_id, 'recipient_id': user['id']})
        if not claim:
            flash('Claim not found', 'danger')
            return redirect(url_for('recipient_feedback'))
        
        # Enrich with donation info
        donation = mongo.db.donations.find_one({'_id': claim['donation_id']})
        if donation:
            donor = mongo.db.users.find_one({'_id': donation['donor_id']})
            claim['donation'] = donation
            if donor:
                claim['donation']['donor'] = donor
        
        if request.method == 'POST':
            rating = int(request.form.get('rating'))
            food_quality = request.form.get('food_quality')
            food_safety = request.form.get('food_safety')
            comments = request.form.get('comments', '')
            report_issue = request.form.get('report_issue') == 'on'
            
            feedback = {
                'claim_id': claim_id,
                'recipient_id': user['id'],
                'rating': rating,
                'food_quality': food_quality,
                'food_safety': food_safety,
                'comments': comments,
                'report_issue': report_issue,
                'created_at': datetime.utcnow()
            }
            
            mongo.db.feedback.insert_one(feedback)
            
            # Update claim with feedback
            mongo.db.claims.update_one({'_id': claim_id}, {'$set': {'feedback': True}})
            
            # If reported as unsafe, flag for admin review
            if report_issue or food_safety == 'no':
                mongo.db.donations.update_one({'_id': claim['donation_id']}, {
                    '$set': {'flagged_for_review': True, 'flagged_reason': 'User reported unsafe food'}
                })
            
            # Send feedback notification to donor
            send_feedback_notification(claim['donation_id'], rating, comments)
            
            flash('Thank you for your feedback!', 'success')
            return redirect(url_for('recipient_feedback'))
        
        return render_template('recipient/feedback.html', claim=claim, user=user)
    else:
        # General feedback page
        recent_claims = list(mongo.db.claims.find({
            'recipient_id': user['id'],
            'status': 'collected',
            'collected_at': {'$exists': True}
        }).sort('collected_at', -1).limit(10))
        
        # Enrich claims with donation info
        for claim in recent_claims:
            donation = mongo.db.donations.find_one({'_id': claim['donation_id']})
            if donation:
                claim['donation'] = donation
        
        # Get user's rating statistics
        feedbacks = list(mongo.db.feedback.find({'recipient_id': user['id']}))
        total_ratings = len(feedbacks)
        avg_rating = sum(f['rating'] for f in feedbacks) / total_ratings if total_ratings > 0 else 0
        
        rating_counts = {}
        for i in range(1, 6):
            rating_counts[i] = len([f for f in feedbacks if f['rating'] == i])
        
        return render_template('recipient/feedback.html', 
                             recent_claims=recent_claims,
                             avg_rating=avg_rating,
                             total_ratings=total_ratings,
                             rating_counts=rating_counts,
                             user=user)

# ----- Pickup verification (NGO/Donor scans QR) -----
@app.route('/verify/pickup', methods=['GET','POST'])
def verify_pickup():
    # Token-based verification; no login required so QR works on any device
    token = request.values.get('t')
    data = verify_token(token) if token else None
    if not data or data.get('type') != 'claim':
        flash('Invalid or expired QR', 'danger')
        return redirect(url_for('index'))

    claim = mongo.db.claims.find_one({'_id': data['claim_id']})
    if not claim:
        flash('Claim not found', 'danger')
        return redirect(url_for('index'))

    # On GET, show confirmation page with Agree button
    if request.method == 'GET':
        donation = mongo.db.donations.find_one({'_id': claim['donation_id']})
        return render_template('recipient/verify_pickup.html', claim=claim, donation=donation, user=current_user(), token=token)

    # On POST, perform the verification and mark collected
    mongo.db.claims.update_one(
        {'_id': claim['_id']},
        {'$set': {'status': 'collected', 'collected_at': datetime.utcnow()}}
    )
    mongo.db.donations.update_one(
        {'_id': claim['donation_id']},
        {'$set': {'status': 'collected'}}
    )
    flash('Pickup verified and marked as collected.', 'success')
    user = current_user()
    if user and user.get('role') == 'recipient':
        return redirect(url_for('recipient_claim_history'))
    return redirect(url_for('index'))

# ----- Admin -----
@app.route('/admin/pending')
@login_required
def admin_pending():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    pending = list(mongo.db.donations.find({'status': 'pending_review'}))
    # Enrich with donor and expiry info
    for p in pending:
        donor = mongo.db.users.find_one({'_id': p.get('donor_id')})
        if donor:
            p['donor'] = {'name': donor.get('name'), 'email': donor.get('email'), 'phone': donor.get('phone')}
        expires_at = p.get('expires_at')
        try:
            p['expires_at_iso'] = expires_at.isoformat() if expires_at else None
        except Exception:
            p['expires_at_iso'] = None
    return render_template('admin/pending.html', pending=pending, user=user)

@app.route('/admin/action/<donation_id>/<action>')
@login_required
def admin_action(donation_id, action):
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    if action not in ('approve','reject','compost'):
        flash('Invalid action', 'danger')
        return redirect(url_for('admin_pending'))
    status_map = {'approve':'approved','reject':'rejected','compost':'compost'}
    mongo.db.donations.update_one({'_id': donation_id}, {'$set': {'status': status_map[action]}})
    # Log admin action
    log_action(user['id'], user['role'], f"donation_{action}", target_type='donation', target_id=donation_id)
    
    # Send notification for approval
    if action == 'approve':
        send_donation_approved_notification(donation_id)
    
    flash('Action applied', 'success')
    return redirect(url_for('admin_pending'))

# Analytics Dashboard (Admin)
@app.route('/admin/analytics')
@login_required
def admin_analytics():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Basic stats
    stats = {
        'total_donations': mongo.db.donations.count_documents({}),
        'total_claims': mongo.db.claims.count_documents({}),
        'composted': mongo.db.donations.count_documents({'status': 'compost'}),
        'pending': mongo.db.donations.count_documents({'status': 'pending_review'}),
        'approved': mongo.db.donations.count_documents({'status': 'approved'}),
        'rejected': mongo.db.donations.count_documents({'status': 'rejected'}),
        'expired': mongo.db.donations.count_documents({'status': 'expired'})
    }
    
    # Daily activity data (last 7 days)
    from datetime import timedelta
    now = datetime.utcnow()
    daily_labels = []
    daily_donations = []
    daily_claims = []
    
    for i in range(7):
        date = now - timedelta(days=6-i)
        date_str = date.strftime('%Y-%m-%d')
        daily_labels.append(date.strftime('%b %d'))
        
        # Count donations created on this date
        start_of_day = date.replace(hour=0, minute=0, second=0, microsecond=0)
        end_of_day = start_of_day + timedelta(days=1)
        daily_donations.append(mongo.db.donations.count_documents({
            'created_at': {'$gte': start_of_day, '$lt': end_of_day}
        }))
        
        # Count claims created on this date
        daily_claims.append(mongo.db.claims.count_documents({
            'claimed_at': {'$gte': start_of_day, '$lt': end_of_day}
        }))
    
    # Top donors
    pipeline = [
        {'$match': {'role': 'donor'}},
        {'$lookup': {
            'from': 'donations',
            'localField': '_id',
            'foreignField': 'donor_id',
            'as': 'donations'
        }},
        {'$addFields': {'donation_count': {'$size': '$donations'}}},
        {'$sort': {'donation_count': -1}},
        {'$limit': 5}
    ]
    top_donors = list(mongo.db.users.aggregate(pipeline))
    
    # Top locations (simplified - using donor locations)
    top_locations = [
        {'name': 'Downtown Area', 'address': 'Main Street, City Center', 'donation_count': 15},
        {'name': 'University District', 'address': 'Campus Area', 'donation_count': 12},
        {'name': 'Residential Zone', 'address': 'Suburban Area', 'donation_count': 8}
    ]
    
    # Urgent donations (spoilage hotspots)
    urgent_donations = []
    for donation in mongo.db.donations.find({'status': {'$in': ['approved', 'claimed']}}):
        if donation.get('expires_at'):
            time_left = (donation['expires_at'] - now).total_seconds() / 3600
            if time_left < 4 and time_left > 0:
                donor = mongo.db.users.find_one({'_id': donation['donor_id']})
                urgent_donations.append({
                    'food_name': donation['food_name'],
                    'donor_name': donor['name'] if donor else 'Unknown',
                    'location_name': 'Location',
                    'time_left': round(time_left, 1),
                    'urgency': 'high' if time_left < 2 else 'medium'
                })
    
    return render_template('admin/analytics.html', 
                         stats=stats, 
                         daily_labels=daily_labels,
                         daily_donations=daily_donations,
                         daily_claims=daily_claims,
                         top_donors=top_donors,
                         top_locations=top_locations,
                         urgent_donations=urgent_donations,
                         user=user)

# Recipient verification page (Admin)
@app.route('/admin/recipients', methods=['GET','POST'])
@login_required
def admin_recipients():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    q = request.args.get('q', '')
    criteria = {'role':'recipient'}
    if q:
        criteria['$or'] = [{'name': {'$regex': q, '$options': 'i'}}, {'email': {'$regex': q, '$options': 'i'}}, {'phone': {'$regex': q, '$options': 'i'}}]
    recipients = list(mongo.db.users.find(criteria).limit(50))
    return render_template('admin/recipients.html', recipients=recipients, q=q, user=user)

@app.route('/admin/recipient/<user_id>/<action>')
@login_required
def admin_recipient_action(user_id, action):
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    if action not in ('approve','reject'):
        flash('Invalid action', 'danger')
        return redirect(url_for('admin_recipients'))
    status = 'approved' if action=='approve' else 'rejected'
    mongo.db.users.update_one({'_id': user_id, 'role':'recipient'}, {'$set': {'status': status}})
    # Log admin action
    log_action(user['id'], user['role'], f"recipient_{action}", target_type='user', target_id=user_id)
    flash('Recipient updated.', 'success')
    return redirect(url_for('admin_recipients'))

# Issue verification QR for recipient
@app.route('/admin/recipient/<user_id>/issue_qr')
@login_required
def issue_recipient_qr(user_id):
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    rec = mongo.db.users.find_one({'_id': user_id, 'role': 'recipient'})
    if not rec:
        flash('Recipient not found', 'danger')
        return redirect(url_for('admin_recipients'))
    payload = {'type':'recipient_verify','user_id': user_id, 'exp': time.time() + 60*60}
    token = sign_payload(payload)
    qr_path = generate_qr_for_text(token)
    return send_from_directory(os.path.dirname(qr_path), os.path.basename(qr_path), as_attachment=True)

# Flagged Users Management
@app.route('/admin/flagged')
@login_required
def admin_flagged():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Suspicious users (simplified detection)
    suspicious_users = []
    for user_doc in mongo.db.users.find({'role': 'recipient'}):
        # Check for suspicious patterns
        claims = list(mongo.db.claims.find({'recipient_id': user_doc['_id']}))
        if len(claims) > 10:  # Too many claims
            suspicious_users.append({
                '_id': user_doc['_id'],
                'name': user_doc['name'],
                'email': user_doc['email'],
                'phone': user_doc['phone'],
                'issues': ['Excessive claims in short time']
            })
    
    # No-show users
    no_show_users = []
    for user_doc in mongo.db.users.find({'role': 'recipient'}):
        claims = list(mongo.db.claims.find({'recipient_id': user_doc['_id']}))
        no_shows = [c for c in claims if c.get('status') == 'claimed' and not c.get('collected_at')]
        if len(no_shows) > 3:
            no_show_users.append({
                '_id': user_doc['_id'],
                'name': user_doc['name'],
                'email': user_doc['email'],
                'phone': user_doc['phone'],
                'no_show_count': len(no_shows),
                'no_show_rate': round((len(no_shows) / len(claims)) * 100, 1) if claims else 0,
                'last_activity': user_doc.get('created_at', datetime.utcnow()).strftime('%Y-%m-%d')
            })
    
    # Fake details users (simplified detection)
    fake_detail_users = []
    for user_doc in mongo.db.users.find({'role': 'recipient'}):
        issues = []
        if len(user_doc.get('name', '')) < 2:
            issues.append('Suspiciously short name')
        if '@' not in user_doc.get('email', ''):
            issues.append('Invalid email format')
        if len(user_doc.get('phone', '')) < 10:
            issues.append('Invalid phone number')
        
        if issues:
            fake_detail_users.append({
                '_id': user_doc['_id'],
                'name': user_doc['name'],
                'email': user_doc['email'],
                'phone': user_doc['phone'],
                'detected_issues': issues
            })
    
    return render_template('admin/flagged_users.html', 
                         suspicious_users=suspicious_users,
                         no_show_users=no_show_users,
                         fake_detail_users=fake_detail_users,
                         user=user)

# Donation Assignment
@app.route('/admin/assign')
@login_required
def admin_assign_donations():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get approved donations that can be assigned
    donations = list(mongo.db.donations.find({
        'status': 'approved',
        'distribution_status': {'$in': ['pending', 'assigned']}
    }).sort('created_at', -1))
    
    # Enrich with assigned recipient info
    for donation in donations:
        if donation.get('assigned_recipient'):
            recipient = mongo.db.users.find_one({'_id': donation['assigned_recipient']})
            if recipient:
                donation['assigned_recipient'] = recipient
    
    return render_template('admin/assign_donations.html', donations=donations, user=user)

# Admin profile and history
@app.route('/admin/profile')
@login_required
def admin_profile():
    user = current_user()
    if user['role'] != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    db_user = mongo.db.users.find_one({'_id': user['id']})

    # Recent generic history
    actions = list(mongo.db.audit_logs.find({'actor_id': user['id']}).sort('timestamp', -1).limit(100))

    # Donations I reviewed (approve/reject/compost)
    donation_logs = list(mongo.db.audit_logs.find({
        'actor_id': user['id'],
        'action': {'$in': ['donation_approve', 'donation_reject', 'donation_compost']}
    }).sort('timestamp', -1).limit(50))
    donations_reviewed = []
    for lg in donation_logs:
        donation = mongo.db.donations.find_one({'_id': lg.get('target_id')})
        donor = mongo.db.users.find_one({'_id': (donation or {}).get('donor_id')}) if donation else None
        donations_reviewed.append({
            'action': lg.get('action'),
            'timestamp': lg.get('timestamp'),
            'donation_id': lg.get('target_id'),
            'food_name': (donation or {}).get('food_name', 'Unknown'),
            'donor_name': (donor or {}).get('name', 'Unknown')
        })

    # Recipients I approved
    recip_logs = list(mongo.db.audit_logs.find({
        'actor_id': user['id'],
        'action': 'recipient_approve'
    }).sort('timestamp', -1).limit(50))
    recipients_approved = []
    for lg in recip_logs:
        r = mongo.db.users.find_one({'_id': lg.get('target_id')})
        recipients_approved.append({
            'timestamp': lg.get('timestamp'),
            'recipient_id': lg.get('target_id'),
            'name': (r or {}).get('name', 'Unknown'),
            'email': (r or {}).get('email', ''),
            'phone': (r or {}).get('phone', '')
        })

    return render_template(
        'admin/profile.html',
        user=user,
        db_user=db_user,
        actions=actions,
        donations_reviewed=donations_reviewed,
        recipients_approved=recipients_approved
    )

@app.route('/admin/donations/<donation_id>')
@login_required
def get_donation_details(donation_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'error': 'Access denied'}, 403
    
    donation = mongo.db.donations.find_one({'_id': donation_id})
    if not donation:
        return {'error': 'Donation not found'}, 404
    
    # Remove sensitive data
    donation.pop('_id', None)
    return donation

@app.route('/admin/recipients/list')
@login_required
def get_recipients_list():
    user = current_user()
    if user['role'] != 'admin':
        return jsonify({'error': 'Access denied'}), 403
    
    # Include _id for selection, and return proper JSON
    recipients = list(mongo.db.users.find({
        'role': 'recipient',
        'status': 'approved'
    }, {'_id': 1, 'name': 1, 'email': 1, 'phone': 1, 'location': 1}))
    
    for r in recipients:
        r['_id'] = str(r.get('_id'))
    
    return jsonify(recipients)

@app.route('/admin/donations/<donation_id>/assign', methods=['POST'])
@login_required
def assign_donation_to_recipient(donation_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'error': 'Access denied'}, 403
    
    data = request.get_json()
    recipient_id = data.get('recipient_id')
    
    if not recipient_id:
        return {'error': 'Recipient ID required'}, 400
    
    # Update donation with assignment
    result = mongo.db.donations.update_one(
        {'_id': donation_id},
        {
            '$set': {
                'assigned_recipient': recipient_id,
                'distribution_status': 'assigned',
                'assigned_at': datetime.utcnow(),
                'assigned_by': user['id']
            }
        }
    )
    
    if result.modified_count:
        # Log admin action
        log_action(user['id'], user['role'], 'assign_donation', target_type='donation', target_id=donation_id, details={'recipient_id': recipient_id})
        # Send notification to recipient
        from utils.notifications import send_notification
        send_notification(
            recipient_id,
            'donation_assigned',
            'New Donation Assigned',
            f'A donation has been assigned to you for distribution.',
            'info'
        )
        
        return {'success': True, 'message': 'Donation assigned successfully'}
    else:
        return {'error': 'Failed to assign donation'}, 500

@app.route('/admin/donations/<donation_id>/distributed', methods=['POST'])
@login_required
def mark_donation_distributed(donation_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'error': 'Access denied'}, 403
    
    result = mongo.db.donations.update_one(
        {'_id': donation_id},
        {
            '$set': {
                'distribution_status': 'distributed',
                'distributed_at': datetime.utcnow(),
                'distributed_by': user['id']
            }
        }
    )
    
    if result.modified_count:
        log_action(user['id'], user['role'], 'mark_distributed', target_type='donation', target_id=donation_id)
        return {'success': True, 'message': 'Donation marked as distributed'}
    else:
        return {'error': 'Failed to update status'}, 500

@app.route('/admin/donations/<donation_id>/mark_donated', methods=['POST'])
@login_required
def mark_donation_as_donated(donation_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'error': 'Access denied'}, 403

    result = mongo.db.donations.update_one(
        {'_id': donation_id},
        {
            '$set': {
                'status': 'collected',
                'distribution_status': 'distributed',
                'distributed_at': datetime.utcnow(),
                'distributed_by': user['id']
            }
        }
    )

    if result.modified_count:
        log_action(user['id'], user['role'], 'mark_donated', target_type='donation', target_id=donation_id)
        try:
            from utils.notifications import send_notification
            donation = mongo.db.donations.find_one({'_id': donation_id})
            if donation:
                send_notification(
                    donation['donor_id'],
                    'distribution_completed',
                    'Donation Distributed',
                    f"Your donation \"{donation.get('food_name', '')}\" has been distributed to recipients.",
                    'success'
                )
        except Exception as e:
            print(f"Notification error: {e}")
        return {'success': True, 'message': 'Donation marked as donated'}
    else:
        return {'error': 'Failed to update status'}, 500

# Recipient Distribution Portal
@app.route('/recipient/distribution')
@login_required
def recipient_distribution():
    user = current_user()
    if user['role'] != 'recipient':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get assigned donations for this recipient
    assigned_donations = list(mongo.db.donations.find({
        'assigned_recipient': user['id'],
        'distribution_status': 'assigned'
    }))
    
    # Get active distributions
    active_distributions = list(mongo.db.distributions.find({
        'recipient_id': user['id'],
        'status': 'in_progress'
    }))
    
    # Enrich with donation details
    for distribution in active_distributions:
        donation = mongo.db.donations.find_one({'_id': distribution['donation_id']})
        if donation:
            distribution['donation'] = donation
    
    # Get distribution history
    distribution_history = list(mongo.db.distributions.find({
        'recipient_id': user['id']
    }).sort('created_at', -1).limit(20))
    
    # Enrich with donation details
    for distribution in distribution_history:
        donation = mongo.db.donations.find_one({'_id': distribution['donation_id']})
        if donation:
            distribution['donation'] = donation
    
    return render_template('recipient/distribution.html',
                         assigned_donations=assigned_donations,
                         active_distributions=active_distributions,
                         distribution_history=distribution_history,
                         user=user)

@app.route('/recipient/distribution/<donation_id>/start', methods=['POST'])
@login_required
def start_distribution(donation_id):
    user = current_user()
    if user['role'] != 'recipient':
        return {'error': 'Access denied'}, 403
    
    # Check if donation is assigned to this recipient
    donation = mongo.db.donations.find_one({
        '_id': donation_id,
        'assigned_recipient': user['id']
    })
    
    if not donation:
        return {'error': 'Donation not assigned to you'}, 404
    
    # Create distribution record
    distribution = {
        '_id': str(uuid.uuid4()),
        'donation_id': donation_id,
        'recipient_id': user['id'],
        'status': 'in_progress',
        'distributed_count': 0,
        'distribution_locations': [],
        'created_at': datetime.utcnow()
    }
    
    mongo.db.distributions.insert_one(distribution)
    
    # Update donation status
    mongo.db.donations.update_one(
        {'_id': donation_id},
        {'$set': {'distribution_status': 'in_progress'}}
    )
    
    return {'success': True, 'message': 'Distribution started successfully'}

@app.route('/recipient/distribution/<distribution_id>')
@login_required
def get_distribution_details(distribution_id):
    user = current_user()
    if user['role'] != 'recipient':
        return {'error': 'Access denied'}, 403
    
    distribution = mongo.db.distributions.find_one({
        '_id': distribution_id,
        'recipient_id': user['id']
    })
    
    if not distribution:
        return {'error': 'Distribution not found'}, 404
    
    # Get donation details
    donation = mongo.db.donations.find_one({'_id': distribution['donation_id']})
    if donation:
        distribution['donation'] = donation
    
    return distribution

@app.route('/recipient/distribution/<distribution_id>/update', methods=['POST'])
@login_required
def update_distribution(distribution_id):
    user = current_user()
    if user['role'] != 'recipient':
        return {'error': 'Access denied'}, 403
    
    data = request.get_json()
    distributed_quantity = data.get('distributed_quantity', 0)
    distribution_location = data.get('distribution_location')
    notes = data.get('notes', '')
    is_complete = data.get('is_complete', False)
    
    # Get current distribution
    distribution = mongo.db.distributions.find_one({
        '_id': distribution_id,
        'recipient_id': user['id']
    })
    
    if not distribution:
        return {'error': 'Distribution not found'}, 404
    
    # Update distribution
    update_data = {
        'distributed_count': distribution.get('distributed_count', 0) + distributed_quantity,
        'last_updated': datetime.utcnow()
    }
    
    if distribution_location:
        update_data['distribution_locations'] = distribution.get('distribution_locations', []) + [{
            'location': distribution_location,
            'quantity': distributed_quantity,
            'notes': notes,
            'timestamp': datetime.utcnow()
        }]
    
    if is_complete:
        update_data['status'] = 'completed'
        update_data['completed_at'] = datetime.utcnow()
    
    mongo.db.distributions.update_one(
        {'_id': distribution_id},
        {'$set': update_data}
    )
    
    # Update donation status if complete
    if is_complete:
        mongo.db.donations.update_one(
            {'_id': distribution['donation_id']},
            {'$set': {'distribution_status': 'distributed'}}
        )
        
        # Send notification to admin
        from utils.notifications import send_notification
        send_notification(
            'admin',  # This would be the admin user ID
            'distribution_completed',
            'Distribution Completed',
            f'Distribution of {distribution["donation_id"]} has been completed by {user["name"]}.',
            'info'
        )
    
    return {'success': True, 'message': 'Distribution updated successfully'}

@app.route('/recipient/distribution/points')
@login_required
def get_distribution_points():
    user = current_user()
    if user['role'] != 'recipient':
        return {'error': 'Access denied'}, 403
    
    # Mock distribution points - in production, this would come from a database
    distribution_points = [
        {
            'id': 'shelter_1',
            'name': 'Homeless Shelter - Downtown',
            'address': '123 Main Street, Downtown',
            'lat': 20.5937,
            'lng': 78.9629,
            'capacity': 50,
            'hours': '24/7',
            'contact': '+91 98765 43210'
        },
        {
            'id': 'shelter_2',
            'name': 'Community Center - North',
            'address': '456 North Avenue, North District',
            'lat': 20.6037,
            'lng': 78.9729,
            'capacity': 30,
            'hours': '6 AM - 10 PM',
            'contact': '+91 98765 43211'
        },
        {
            'id': 'shelter_3',
            'name': 'Food Bank - East',
            'address': '789 East Road, East District',
            'lat': 20.5837,
            'lng': 78.9529,
            'capacity': 100,
            'hours': '8 AM - 8 PM',
            'contact': '+91 98765 43212'
        },
        {
            'id': 'shelter_4',
            'name': 'Church Kitchen - South',
            'address': '321 South Street, South District',
            'lat': 20.5737,
            'lng': 78.9429,
            'capacity': 25,
            'hours': '7 AM - 9 PM',
            'contact': '+91 98765 43213'
        }
    ]
    
    return distribution_points

# User management actions
@app.route('/admin/user/<user_id>/warn', methods=['POST'])
@login_required
def admin_warn_user(user_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'success': False, 'message': 'Access denied'}
    
    # Add warning to user record
    mongo.db.users.update_one({'_id': user_id}, {
        '$push': {'warnings': {
            'date': datetime.utcnow(),
            'admin_id': user['id'],
            'reason': 'Suspicious activity detected'
        }}
    })
    
    return {'success': True, 'message': 'Warning sent'}

@app.route('/admin/user/<user_id>/suspend', methods=['POST'])
@login_required
def admin_suspend_user(user_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'success': False, 'message': 'Access denied'}
    
    mongo.db.users.update_one({'_id': user_id}, {
        '$set': {
            'status': 'suspended',
            'suspended_at': datetime.utcnow(),
            'suspended_by': user['id']
        }
    })
    
    return {'success': True, 'message': 'User suspended'}

@app.route('/admin/user/<user_id>/block', methods=['POST'])
@login_required
def admin_block_user(user_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'success': False, 'message': 'Access denied'}
    
    mongo.db.users.update_one({'_id': user_id}, {
        '$set': {
            'status': 'blocked',
            'blocked_at': datetime.utcnow(),
            'blocked_by': user['id']
        }
    })
    
    return {'success': True, 'message': 'User blocked'}

@app.route('/admin/user/<user_id>/limit', methods=['POST'])
@login_required
def admin_limit_user(user_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'success': False, 'message': 'Access denied'}
    
    mongo.db.users.update_one({'_id': user_id}, {
        '$set': {
            'claim_limit': 1,
            'claim_limit_period': 'daily',
            'limited_at': datetime.utcnow(),
            'limited_by': user['id']
        }
    })
    
    return {'success': True, 'message': 'Claims limited'}

@app.route('/admin/user/<user_id>/verify', methods=['POST'])
@login_required
def admin_verify_user(user_id):
    user = current_user()
    if user['role'] != 'admin':
        return {'success': False, 'message': 'Access denied'}
    
    mongo.db.users.update_one({'_id': user_id}, {
        '$set': {
            'verified': True,
            'verified_at': datetime.utcnow(),
            'verified_by': user['id']
        }
    })
    
    return {'success': True, 'message': 'User verified'}

# ----- Super Admin -----
@app.route('/super/dashboard')
@login_required
def superadmin_dashboard():
    user = current_user()
    if user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    total_donations = mongo.db.donations.count_documents({})
    total_claims = mongo.db.claims.count_documents({})
    composted = mongo.db.donations.count_documents({'status':'compost'})
    # stats by status
    approved = mongo.db.donations.count_documents({'status':'approved'})
    pending = mongo.db.donations.count_documents({'status':'pending_review'})
    rejected = mongo.db.donations.count_documents({'status':'rejected'})
    compost = mongo.db.donations.count_documents({'status':'compost'})
    expired = mongo.db.donations.count_documents({'status':'expired'})
    admins = mongo.db.users.count_documents({'role':'admin'})
    top_donors = list(mongo.db.users.find({'role':'donor'}).limit(5))
    stats = {'total_donations': total_donations, 'total_claims': total_claims, 'composted': composted, 'approved': approved, 'pending': pending, 'rejected': rejected, 'compost': compost, 'expired': expired, 'admins': admins}
    
    # Fraud alerts
    fraud_alerts = list(mongo.db.users.find({'status': {'$in': ['suspended', 'blocked']}}).limit(5))
    
    # Spoilage alerts
    now = datetime.utcnow()
    spoilage_alerts = list(mongo.db.donations.find({
        'status': {'$in': ['approved', 'claimed']},
        'expires_at': {'$lt': now + timedelta(hours=2)}
    }).limit(5))
    
    return render_template('superadmin/dashboard.html', 
                         stats=stats, 
                         top_donors=top_donors, 
                         fraud_alerts=fraud_alerts,
                         spoilage_alerts=spoilage_alerts,
                         user=user)

# Fraud Detection
@app.route('/super/fraud')
@login_required
def superadmin_fraud():
    user = current_user()
    if user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Fraud statistics
    fraud_stats = {
        'suspicious_users': mongo.db.users.count_documents({'status': 'suspended'}),
        'fake_donations': mongo.db.donations.count_documents({'flagged_for_review': True}),
        'blocked_users': mongo.db.users.count_documents({'status': 'blocked'}),
        'resolved_cases': mongo.db.audit_logs.count_documents({'action': 'fraud_resolved'})
    }
    
    # Suspicious patterns (simplified detection)
    excessive_count = 0
    try:
        doc = next(mongo.db.claims.aggregate([
            {'$group': {'_id': '$recipient_id', 'count': {'$sum': 1}}},
            {'$match': {'count': {'$gt': 10}}},
            {'$count': 'total'}
        ]))
        excessive_count = doc.get('total', 0)
    except StopIteration:
        excessive_count = 0

    suspicious_patterns = [
        {
            'id': 'excessive_claims',
            'title': 'Excessive Claims Pattern',
            'description': 'Users claiming more than 10 donations in a short period',
            'risk_level': 'high',
            'count': excessive_count,
            'users_affected': 5,
            'last_detected': '2024-01-15'
        },
        {
            'id': 'no_show_pattern',
            'title': 'Frequent No-Show Pattern',
            'description': 'Users consistently claiming but not collecting food',
            'risk_level': 'medium',
            'count': 12,
            'users_affected': 3,
            'last_detected': '2024-01-14'
        }
    ]
    
    # Anomalies
    anomalies = [
        {
            'id': 'anomaly_1',
            'type': 'Unusual Donation Pattern',
            'description': 'User uploaded 20 donations in 1 hour',
            'severity': 'high',
            'user_name': 'John Doe',
            'detected_at': '2024-01-15 14:30',
            'confidence': 95
        }
    ]
    
    # User reports
    user_reports = [
        {
            'id': 'report_1',
            'report_type': 'Fake Donation',
            'description': 'User reported receiving spoiled food',
            'priority': 'high',
            'reporter_name': 'Jane Smith',
            'target_name': 'Restaurant ABC',
            'reported_at': '2024-01-15 10:00',
            'status': 'pending'
        }
    ]
    
    return render_template('superadmin/fraud.html',
                         fraud_stats=fraud_stats,
                         suspicious_patterns=suspicious_patterns,
                         anomalies=anomalies,
                         user_reports=user_reports,
                         user=user)

# Audit Logs
@app.route('/super/logs')
@login_required
def superadmin_logs():
    user = current_user()
    if user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get audit logs (simplified - in production, use proper audit logging)
    logs = list(mongo.db.audit_logs.find().sort('timestamp', -1).limit(100))
    
    return render_template('superadmin/logs.html', logs=logs, user=user)

# Spoilage Monitoring
@app.route('/super/spoilage')
@login_required
def superadmin_spoilage():
    user = current_user()
    if user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    now = datetime.utcnow()
    
    # High-risk donations
    high_risk = list(mongo.db.donations.find({
        'status': {'$in': ['approved', 'claimed']},
        'expires_at': {'$lt': now + timedelta(hours=2)}
    }))
    
    # Medium-risk donations
    medium_risk = list(mongo.db.donations.find({
        'status': {'$in': ['approved', 'claimed']},
        'expires_at': {'$gte': now + timedelta(hours=2), '$lt': now + timedelta(hours=4)}
    }))
    
    # Spoilage trends
    spoilage_trends = {
        'daily_waste': 15,  # kg
        'weekly_waste': 105,  # kg
        'monthly_waste': 450,  # kg
        'waste_reduction': 12  # percentage
    }
    
    return render_template('superadmin/spoilage.html',
                         high_risk=high_risk,
                         medium_risk=medium_risk,
                         spoilage_trends=spoilage_trends,
                         now=now,
                         user=user)

# Super Admin Distribution Tracking
@app.route('/super/tracking')
@login_required
def superadmin_tracking():
    user = current_user()
    if user['role'] != 'superadmin':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    # Get tracking statistics
    tracking_stats = {
        'total_donations': mongo.db.donations.count_documents({}),
        'assigned_donations': mongo.db.donations.count_documents({'distribution_status': 'assigned'}),
        'distributed_donations': mongo.db.donations.count_documents({'distribution_status': 'distributed'}),
        'pending_distributions': mongo.db.distributions.count_documents({'status': 'in_progress'}),
        'uploaded_count': mongo.db.donations.count_documents({'status': 'approved'}),
        'ai_approved': mongo.db.donations.count_documents({'ai_label': 'safe'}),
        'assigned_count': mongo.db.donations.count_documents({'assigned_recipient': {'$ne': None}}),
        'distributed_count': mongo.db.donations.count_documents({'distribution_status': 'distributed'})
    }
    
    # Get recent activities
    recent_activities = [
        {
            'icon': 'upload',
            'color': 'primary',
            'message': 'New donation uploaded from Taj Palace Restaurant',
            'timestamp': '2 minutes ago'
        },
        {
            'icon': 'person-plus',
            'color': 'info',
            'message': 'Donation assigned to John Doe for distribution',
            'timestamp': '15 minutes ago'
        },
        {
            'icon': 'truck',
            'color': 'success',
            'message': 'Distribution completed at Homeless Shelter Downtown',
            'timestamp': '1 hour ago'
        },
        {
            'icon': 'exclamation-triangle',
            'color': 'warning',
            'message': 'Distribution delayed for Pizza Corner donation',
            'timestamp': '2 hours ago'
        }
    ]
    
    # Get donors data (all types)
    donors = []
    donor_pipeline = [
        {'$group': {
            '_id': {'name': '$donor_name', 'type': '$donor_type'},
            'total_donations': {'$sum': 1},
            'distributed_donations': {'$sum': {'$cond': [{'$eq': ['$distribution_status', 'distributed']}, 1, 0]}},
            'address': {'$first': '$donor_address'},
            'contact': {'$first': '$donor_contact'}
        }},
        {'$sort': {'total_donations': -1}},
        {'$limit': 15}
    ]
    
    for donor in mongo.db.donations.aggregate(donor_pipeline):
        _id = donor.get('_id') or {}
        dname = (_id.get('name') or donor.get('donor_name') or 'Unknown Donor')
        dtype = _id.get('type') or donor.get('donor_type') or 'unknown'
        donors.append({
            'id': str(dname).replace(' ', '_').lower(),
            'name': dname,
            'type': dtype,
            'address': donor.get('address', '—'),
            'contact': donor.get('contact', '—'),
            'total_donations': donor.get('total_donations', 0),
            'distributed_donations': donor.get('distributed_donations', 0),
            'status': 'active'
        })
    
    # Get recipients data
    recipients = []
    recipient_pipeline = [
        {'$match': {'role': 'recipient'}},
        {'$lookup': {
            'from': 'donations',
            'localField': '_id',
            'foreignField': 'assigned_recipient',
            'as': 'assigned_donations'
        }},
        {'$addFields': {
            'assigned_count': {'$size': '$assigned_donations'},
            'distributed_count': {
                '$size': {
                    '$filter': {
                        'input': '$assigned_donations',
                        'cond': {'$eq': ['$$this.distribution_status', 'distributed']}
                    }
                }
            }
        }},
        {'$addFields': {
            'success_rate': {
                '$cond': [
                    {'$gt': ['$assigned_count', 0]},
                    {'$multiply': [{'$divide': ['$distributed_count', '$assigned_count']}, 100]},
                    0
                ]
            }
        }},
        {'$sort': {'assigned_count': -1}},
        {'$limit': 20}
    ]
    
    for recipient in mongo.db.users.aggregate(recipient_pipeline):
        recipients.append({
            'name': recipient['name'],
            'email': recipient['email'],
            'phone': recipient['phone'],
            'assigned_count': recipient['assigned_count'],
            'distributed_count': recipient['distributed_count'],
            'success_rate': round(recipient['success_rate'], 1),
            'last_activity': recipient.get('last_login', 'Never'),
            'status': 'active' if recipient.get('status') == 'approved' else 'inactive'
        })
    
    # Get active distributions
    active_distributions = list(mongo.db.distributions.find({
        'status': {'$in': ['in_progress', 'assigned']}
    }).sort('created_at', -1).limit(10))
    
    # Enrich with donation and recipient details
    for distribution in active_distributions:
        donation = mongo.db.donations.find_one({'_id': distribution['donation_id']})
        recipient = mongo.db.users.find_one({'_id': distribution['recipient_id']})
        
        if donation:
            distribution['donation'] = donation
        if recipient:
            distribution['recipient'] = recipient
        
        # Calculate progress
        if donation:
            distribution['progress'] = (distribution.get('distributed_count', 0) / donation['quantity']) * 100
    
    return render_template('superadmin/tracking.html',
                         tracking_stats=tracking_stats,
                         recent_activities=recent_activities,
                         donors=donors,
                         recipients=recipients,
                         active_distributions=active_distributions,
                         user=user)

# ----- Food Inspector -----
@app.route('/inspector/dashboard')
@login_required
def inspector_dashboard():
    user = current_user()
    if user['role'] != 'inspector':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    # Inspector overview: recent donations needing review and recipient activity
    pending = list(mongo.db.donations.find({'status': {'$in': ['pending_review','expired']}}).sort('created_at', -1).limit(20))
    recent_claims = list(mongo.db.claims.find({}).sort('created_at', -1).limit(20))
    return render_template('inspector/dashboard.html', user=user, pending=pending, recent_claims=recent_claims)

@app.route('/inspector/recipients')
@login_required
def inspector_recipients():
    user = current_user()
    if user['role'] != 'inspector':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    # Manage recipient activities: list recipients with basic stats
    pipeline = [
        {'$match': {'role': 'recipient'}},
        {'$lookup': {
            'from': 'claims',
            'localField': '_id',
            'foreignField': 'recipient_id',
            'as': 'claims'
        }},
        {'$addFields': {
            'claims_count': {'$size': '$claims'},
            'collected_count': {
                '$size': {
                    '$filter': {
                        'input': '$claims',
                        'cond': {'$eq': ['$$this.status', 'collected']}
                    }
                }
            }
        }},
        {'$project': {'claims': 0}},
        {'$sort': {'claims_count': -1}},
        {'$limit': 100}
    ]
    recipients = list(mongo.db.users.aggregate(pipeline))
    return render_template('inspector/recipients.html', user=user, recipients=recipients)

@app.route('/inspector/recipient/<recipient_id>')
@login_required
def inspector_recipient_detail(recipient_id):
    user = current_user()
    if user['role'] != 'inspector':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    recipient = mongo.db.users.find_one({'_id': recipient_id})
    if not recipient:
        flash('Recipient not found', 'danger')
        return redirect(url_for('inspector_recipients'))
    claims = list(mongo.db.claims.find({'recipient_id': recipient_id}).sort('created_at', -1))
    return render_template('inspector/recipient_detail.html', user=user, recipient=recipient, claims=claims)

# Notifications
@app.route('/notifications')
@login_required
def user_notifications():
    user = current_user()
    notifications = get_user_notifications(user['id'])
    return render_template('notifications.html', notifications=notifications, user=user)

@app.route('/notifications/<notification_id>/read', methods=['POST'])
@login_required
def mark_notification_as_read(notification_id):
    user = current_user()
    mark_notification_read(notification_id, user['id'])
    return {'success': True}

# ----- Utilities: static uploads -----
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


# ---------- Expiry check task ----------
def check_and_mark_expired():
    from datetime import datetime
    now = datetime.utcnow()
    expired = mongo.db.donations.update_many({'expires_at': {'$lte': now}, 'status': {'$nin': ['expired','collected','rejected','compost']}}, {'$set': {'status': 'expired'}})
    if expired.modified_count:
        print(f"Marked {expired.modified_count} donations as expired")

scheduler = BackgroundScheduler()
scheduler.add_job(func=check_and_mark_expired, trigger='interval', minutes=10)
scheduler.start()
# Shutdown scheduler on exit
import atexit
atexit.register(lambda: scheduler.shutdown())

if __name__ == '__main__':
    # Bind to all interfaces so QR links work from phones on the same network.
    # In production, run behind a real WSGI server instead.
    app.run(debug=True, host='0.0.0.0')
