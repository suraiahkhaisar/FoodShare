# Food Donation Platform - Flask + MongoDB + Bootstrap (Starter)

This is a **starter full-stack** Flask application implementing the features described in your document:
- Roles: Donor, Recipient, Admin, Super Admin
- Registration & Login (role-based)
- Donor: Add donation, track, history, QR generation
- Recipient: Map view (Leaflet) and claim flow (QR generation)
- Admin: Pending reviews, approve/reject/compost
- Super Admin: System dashboard with charts
- AI safety check (simulated)
- Bootstrap 5 UI, Chart.js, Leaflet placeholders

## How to run (local)

1. Install Python 3.9+.
2. Create virtualenv and install requirements:
   ```
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Configure MongoDB connection:
   - Create a `.env` file in the project root with:
     ```
     MONGO_URI=mongodb://localhost:27017/fooddb
     SECRET_KEY=your-secret-key
     ```
   - Or set `MONGO_URI` environment variable to your MongoDB Atlas URI.

4. Run the app:
   ```
   python app.py
   ```
   App runs at http://127.0.0.1:5000

## Notes
- This starter includes key flows and UI templates. Some advanced features (live AI model, production-ready security hardening, file cleanup, background jobs) are prepared as TODOs or simulation functions.
- The `static/uploads/` folder stores uploaded photos and generated QR images.

Feel free to open issues or ask for expansions; I can extend any module on request.


## New features in v2
- Chart.js analytics on Super Admin dashboard.
- Leaflet heatmap (leaflet-heat) on recipient map to visualize hotspots.
- Background scheduler (APScheduler) to mark expired donations.
- Dockerfile for containerized deployment.
- .env.example expanded with EXTERNAL_AI_ENDPOINT and mail settings placeholder.

## Docker
Build and run:
```
docker build -t foodshare:latest .
docker run -p 5000:5000 --env-file .env foodshare:latest
```
