import os, hmac, json, base64, time
from hashlib import sha256

SECRET = os.getenv('SECRET_KEY', 'devsecret').encode()

# Simple HMAC-signed token with base64url payload

def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()

def b64url_decode(s: str) -> bytes:
    s += '=' * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s)

def sign_payload(payload: dict) -> str:
    body = json.dumps(payload, separators=(',', ':'), sort_keys=True).encode()
    sig = hmac.new(SECRET, body, sha256).hexdigest()
    return b64url_encode(body) + '.' + sig

def verify_token(token: str) -> dict | None:
    try:
        body_b64, sig = token.split('.')
        body = b64url_decode(body_b64)
        expected = hmac.new(SECRET, body, sha256).hexdigest()
        if not hmac.compare_digest(expected, sig):
            return None
        data = json.loads(body.decode())
        exp = data.get('exp')
        if exp and time.time() > float(exp):
            return None
        return data
    except Exception:
        return None